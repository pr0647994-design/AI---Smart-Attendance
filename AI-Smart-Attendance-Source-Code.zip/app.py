from flask import Flask, render_template, request, redirect, url_for, flash, Response
from datetime import datetime
import sqlite3
import csv
import io

app = Flask(__name__)
app.secret_key = "smart-attendance-demo-key"

DB_NAME = "attendance.db"


def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            roll_number TEXT NOT NULL UNIQUE
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id)
        )
    """)
    conn.commit()
    conn.close()


@app.route("/")
def home():
    conn = get_db()
    students = conn.execute(
        "SELECT * FROM students ORDER BY id DESC"
    ).fetchall()
    attendance = conn.execute("""
        SELECT attendance.id, students.name, students.roll_number,
               attendance.date, attendance.time, attendance.status
        FROM attendance
        JOIN students ON students.id = attendance.student_id
        ORDER BY attendance.id DESC
    """).fetchall()
    present_count = conn.execute(
        "SELECT COUNT(*) FROM attendance WHERE status = 'Present'"
    ).fetchone()[0]
    conn.close()

    return render_template(
        "index.html",
        students=students,
        attendance=attendance,
        present_count=present_count
    )


@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name", "").strip()
    roll_number = request.form.get("roll_number", "").strip()

    if not name or not roll_number:
        flash("Please enter both student name and roll number.", "error")
        return redirect(url_for("home"))

    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO students (name, roll_number) VALUES (?, ?)",
            (name, roll_number)
        )
        conn.commit()
        flash(f"{name} registered successfully.", "success")
    except sqlite3.IntegrityError:
        flash("That roll number is already registered.", "error")
    finally:
        conn.close()

    return redirect(url_for("home"))


@app.route("/mark_attendance/<int:student_id>", methods=["POST"])
def mark_attendance(student_id):
    conn = get_db()
    student = conn.execute(
        "SELECT * FROM students WHERE id = ?", (student_id,)
    ).fetchone()

    if student is None:
        conn.close()
        flash("Student not found.", "error")
        return redirect(url_for("home"))

    now = datetime.now()
    date = now.strftime("%Y-%m-%d")
    time = now.strftime("%H:%M:%S")

    # Prevent duplicate attendance for the same student on the same date.
    already_marked = conn.execute("""
        SELECT id FROM attendance
        WHERE student_id = ? AND date = ?
    """, (student_id, date)).fetchone()

    if already_marked:
        flash(f"{student['name']} is already marked present today.", "error")
    else:
        conn.execute("""
            INSERT INTO attendance (student_id, date, time, status)
            VALUES (?, ?, ?, ?)
        """, (student_id, date, time, "Present"))
        conn.commit()
        flash(f"Attendance marked for {student['name']}.", "success")

    conn.close()
    return redirect(url_for("home"))


@app.route("/delete_student/<int:student_id>", methods=["POST"])
def delete_student(student_id):
    conn = get_db()
    conn.execute("DELETE FROM attendance WHERE student_id = ?", (student_id,))
    conn.execute("DELETE FROM students WHERE id = ?", (student_id,))
    conn.commit()
    conn.close()
    flash("Student and related attendance records deleted.", "success")
    return redirect(url_for("home"))


@app.route("/export")
def export_csv():
    conn = get_db()
    rows = conn.execute("""
        SELECT students.name, students.roll_number,
               attendance.date, attendance.time, attendance.status
        FROM attendance
        JOIN students ON students.id = attendance.student_id
        ORDER BY attendance.date DESC, attendance.time DESC
    """).fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Student Name", "Roll Number", "Date", "Time", "Status"])

    for row in rows:
        writer.writerow([
            row["name"],
            row["roll_number"],
            row["date"],
            row["time"],
            row["status"]
        ])

    response = Response(output.getvalue(), mimetype="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename=attendance_report.csv"
    return response


init_db()

if __name__ == "__main__":
    app.run(debug=True)
