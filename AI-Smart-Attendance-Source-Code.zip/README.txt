AI Smart Attendance Monitoring System
======================================

Student: Prince Raj
Institute: Greater Noida Institute of Technology
Branch: Information Technology
Mentor: Harendra Kumar

Files:
- app.py              Flask backend
- templates/index.html  Web interface
- static/style.css      Styling
- requirements.txt      Python dependency

Run:
1. Create/activate a virtual environment.
2. Install dependencies:
   python -m pip install -r requirements.txt
3. Start:
   python app.py
4. Open:
   http://127.0.0.1:5000

Features:
- Student registration
- SQLite persistent storage
- Mark student present
- Prevent duplicate attendance on the same date
- Attendance history
- Delete student
- Export attendance as CSV

Note:
This submitted version implements the core smart attendance workflow. It does not claim to perform real face recognition. An actual AI/face-recognition module would need to be integrated separately.
